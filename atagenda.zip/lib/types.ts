export type View = 'agenda' | 'pacientes' | 'medicos' | 'historico' | 'novo-agendamento';

export interface Patient {
  id: string;
  name: string;
  cpf: string;
  birthDate: string;
  gender: string;
  phone: string;
  email: string;
}

export interface Doctor {
  id: string;
  name: string;
  crm: string;
  specialty: string;
  type: 'executante' | 'solicitante' | 'ambos';
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  time: string;
  procedure: string;
  insurance: string;
  status: 'agendado' | 'realizado' | 'cancelado';
  isOverbook?: boolean;
}

export interface ScheduleBlock {
  id: string;
  doctorId: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  reason: string;
}

export interface DaySchedule {
  active: boolean;
  startTime: string;
  endTime: string;
  lunchStart: string;
  lunchEnd: string;
}

export interface ScheduleConfig {
  doctorId: string;
  maxOverbooksPerDay: number;
  slotDuration: number;
  schedule: Record<string, DaySchedule>;
}

import { Patient, Doctor, Appointment, ScheduleBlock, ScheduleConfig } from './types';

export const mockPatients: Patient[] = [
  { id: '1', name: 'Maria Aparecida da Silva', cpf: '123.456.789-00', birthDate: '1978-05-13', gender: 'Feminino', phone: '(11) 98888-7777', email: 'maria@example.com' },
  { id: '2', name: 'José Adair Pereira Magalhães', cpf: '234.567.890-11', birthDate: '1965-10-22', gender: 'Masculino', phone: '(11) 97777-6666', email: 'jose@example.com' },
  { id: '3', name: 'Eliane Silva Marra', cpf: '345.678.901-22', birthDate: '1982-03-05', gender: 'Feminino', phone: '(11) 96666-5555', email: 'eliane@example.com' },
  { id: '4', name: 'Angelica Correia Costa', cpf: '456.789.012-33', birthDate: '1990-12-15', gender: 'Feminino', phone: '(11) 95555-4444', email: 'angelica@example.com' },
];

export const mockDoctors: Doctor[] = [
  { id: '1', name: 'Moacir Bricola', crm: '50678', specialty: 'Cardiologia', type: 'executante' },
  { id: '2', name: 'Andre Yutaka Muta', crm: '96100', specialty: 'Ortopedia', type: 'executante' },
  { id: '3', name: 'Dr. Reinaldo Wady Farah', crm: '12345', specialty: 'Clínico Geral', type: 'ambos' },
];

export const mockAppointments: Appointment[] = [];

export const mockScheduleBlocks: ScheduleBlock[] = [];

const defaultSchedule = {
  '0': { active: false, startTime: '08:00', endTime: '12:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '1': { active: true, startTime: '08:00', endTime: '18:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '2': { active: true, startTime: '08:00', endTime: '18:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '3': { active: true, startTime: '08:00', endTime: '18:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '4': { active: true, startTime: '08:00', endTime: '18:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '5': { active: true, startTime: '08:00', endTime: '18:00', lunchStart: '12:00', lunchEnd: '13:00' },
  '6': { active: false, startTime: '08:00', endTime: '12:00', lunchStart: '12:00', lunchEnd: '13:00' },
};

export const mockScheduleConfigs: ScheduleConfig[] = [
  { doctorId: '1', maxOverbooksPerDay: 2, slotDuration: 15, schedule: JSON.parse(JSON.stringify(defaultSchedule)) },
  { doctorId: '2', maxOverbooksPerDay: 0, slotDuration: 20, schedule: JSON.parse(JSON.stringify(defaultSchedule)) },
  { doctorId: '3', maxOverbooksPerDay: 1, slotDuration: 30, schedule: JSON.parse(JSON.stringify(defaultSchedule)) },
];

'use client';

import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Filter, ChevronDown, Lock } from 'lucide-react';
import { mockDoctors, mockAppointments, mockPatients, mockScheduleBlocks, mockScheduleConfigs } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { format, addDays, startOfWeek, eachDayOfInterval, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import CustomSelect from './CustomSelect';
import { toast } from 'react-toastify';

interface AgendaProps {
  onNewAppointment?: (date: string, time: string, doctorId: string) => void;
}

export default function Agenda({ onNewAppointment }: AgendaProps) {
  const [selectedDoctor, setSelectedDoctor] = useState(mockDoctors[0].id);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewType, setViewType] = useState<'dia' | 'semana'>('dia');
  const [blockToRemove, setBlockToRemove] = useState<any>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const doctorOptions = mockDoctors.map(doc => ({
    id: doc.id,
    name: `Médico: ${doc.name}`
  }));

  const doctorConfig = mockScheduleConfigs.find(c => c.doctorId === selectedDoctor);
  const slotDuration = doctorConfig?.slotDuration || 15;

  let minTime = '23:59';
  let maxTime = '00:00';
  
  if (doctorConfig?.schedule) {
    Object.values(doctorConfig.schedule).forEach(day => {
      if (day.active) {
        if (day.startTime < minTime) minTime = day.startTime;
        if (day.endTime > maxTime) maxTime = day.endTime;
      }
    });
  }

  if (minTime === '23:59') minTime = '08:00';
  if (maxTime === '00:00') maxTime = '18:00';

  const startHour = parseInt(minTime.split(':')[0]);
  const endHour = parseInt(maxTime.split(':')[0]);

  const times: string[] = [];
  for (let h = startHour; h <= endHour; h++) {
    for (let m = 0; m < 60; m += slotDuration) {
      const hourStr = h.toString().padStart(2, '0');
      const minStr = m.toString().padStart(2, '0');
      const timeStr = `${hourStr}:${minStr}`;
      if (timeStr >= minTime && timeStr < maxTime) {
        times.push(timeStr);
      }
    }
  }

  const weekDays = eachDayOfInterval({
    start: startOfWeek(currentDate, { weekStartsOn: 0 }),
    end: addDays(startOfWeek(currentDate, { weekStartsOn: 0 }), 6),
  });

  const getAppointment = (date: Date, time: string) => {
    return mockAppointments.find(app => 
      app.doctorId === selectedDoctor && 
      app.date === format(date, 'yyyy-MM-dd') && 
      app.time === time
    );
  };

  const getPatientName = (id: string) => {
    return mockPatients.find(p => p.id === id)?.name || 'Paciente Desconhecido';
  };

  const getBlock = (date: Date, time: string) => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    return mockScheduleBlocks.find(block => 
      block.doctorId === selectedDoctor && 
      block.date === formattedDate && 
      time >= block.startTime && 
      time < block.endTime
    );
  };

  const getDaySchedule = (date: Date) => {
    const config = mockScheduleConfigs.find(c => c.doctorId === selectedDoctor);
    if (!config || !config.schedule) return null;
    const dayOfWeek = date.getDay().toString();
    return config.schedule[dayOfWeek];
  };

  const isInactiveDay = (date: Date) => {
    const schedule = getDaySchedule(date);
    return !schedule || !schedule.active;
  };

  const isLunchBreak = (date: Date, time: string) => {
    const schedule = getDaySchedule(date);
    if (!schedule || !schedule.active) return false;
    return time >= schedule.lunchStart && time < schedule.lunchEnd;
  };

  const isOutsideRegularHours = (date: Date, time: string) => {
    const schedule = getDaySchedule(date);
    if (!schedule || !schedule.active) return true;
    return time < schedule.startTime || time >= schedule.endTime;
  };

  const getOverbookStatus = (date: Date) => {
    const config = mockScheduleConfigs.find(c => c.doctorId === selectedDoctor);
    if (!config || config.maxOverbooksPerDay === 0) return { allowed: false, max: 0, current: 0 };
    
    const formattedDate = format(date, 'yyyy-MM-dd');
    const dailyAppointments = mockAppointments.filter(app => 
      app.doctorId === selectedDoctor && app.date === formattedDate
    );
    
    let overbookCount = 0;
    dailyAppointments.forEach(app => {
      if (isOutsideRegularHours(date, app.time)) {
        overbookCount++;
      }
    });
    
    return { 
      allowed: overbookCount < config.maxOverbooksPerDay, 
      max: config.maxOverbooksPerDay, 
      current: overbookCount 
    };
  };

  const handleBlockClick = (block: any) => {
    setBlockToRemove(block);
  };

  const confirmRemoveBlock = () => {
    if (!blockToRemove) return;
    const index = mockScheduleBlocks.findIndex(b => b.id === blockToRemove.id);
    if (index > -1) {
      const removedBlock = mockScheduleBlocks.splice(index, 1)[0];
      toast.success(
        <div>
          Bloqueio removido.{' '}
          <button 
            onClick={() => {
              mockScheduleBlocks.push(removedBlock);
              setRefreshKey(k => k + 1);
              toast.info('Bloqueio restaurado.');
            }}
            className="font-bold underline ml-2"
          >
            Desfazer
          </button>
        </div>
      );
      setRefreshKey(k => k + 1);
    }
    setBlockToRemove(null);
  };

  return (
    <div key={refreshKey} className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Filters & Navigation */}
      <div className="p-3 md:p-4 border-b border-slate-200 flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 sm:flex-none">
            <CustomSelect 
              options={doctorOptions}
              value={selectedDoctor}
              onChange={setSelectedDoctor}
              className="w-full sm:w-64"
            />

            <div className="flex items-center bg-slate-100 rounded-lg p-1 shrink-0">
              <button 
                onClick={() => setViewType('dia')}
                className={cn(
                  "px-3 py-1 text-[10px] md:text-xs font-semibold rounded-md transition-all",
                  viewType === 'dia' ? "bg-white shadow-sm text-indigo-600" : "text-slate-500"
                )}
              >
                Dia
              </button>
              <button 
                onClick={() => setViewType('semana')}
                className={cn(
                  "px-3 py-1 text-[10px] md:text-xs font-semibold rounded-md transition-all",
                  viewType === 'semana' ? "bg-white shadow-sm text-indigo-600" : "text-slate-500"
                )}
              >
                Semana
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-2">
            <div className="flex items-center gap-1">
              <button 
                onClick={() => setCurrentDate(addDays(currentDate, viewType === 'dia' ? -1 : -7))}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-600"
              >
                <ChevronLeft size={18} />
              </button>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg">
                <CalendarIcon size={14} className="text-indigo-600" />
                <span className="text-[11px] md:text-sm font-bold capitalize whitespace-nowrap">
                  {format(currentDate, viewType === 'dia' ? "dd 'de' MMM" : "MMMM yyyy", { locale: ptBR })}
                </span>
              </div>
              <button 
                onClick={() => setCurrentDate(addDays(currentDate, viewType === 'dia' ? 1 : 7))}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-600"
              >
                <ChevronRight size={18} />
              </button>
            </div>
            <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600">
              <Filter size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto">
        <div className={cn(
          "grid min-w-[500px] md:min-w-[800px]",
          viewType === 'dia' 
            ? "grid-cols-[60px_1fr] md:grid-cols-[100px_1fr]" 
            : "grid-cols-[60px_repeat(7,1fr)] md:grid-cols-[100px_repeat(7,1fr)]"
        )}>
          {/* Header */}
          <div className="sticky top-0 z-10 bg-slate-50 border-b border-r border-slate-200 h-10"></div>
          {viewType === 'dia' ? (
            <div className="sticky top-0 z-10 bg-slate-50 border-b border-slate-200 h-10 flex items-center justify-center font-bold text-xs uppercase tracking-wider text-slate-500">
              {format(currentDate, "EEEE, dd/MM", { locale: ptBR })}
            </div>
          ) : (
            weekDays.map((day, i) => (
              <div key={i} className="sticky top-0 z-10 bg-slate-50 border-b border-r border-slate-200 h-10 flex flex-col items-center justify-center font-bold uppercase tracking-wider text-slate-500">
                <span className="md:hidden text-[10px]">{format(day, "EEE", { locale: ptBR }).replace('.', '')}</span>
                <span className="hidden md:inline text-xs">{format(day, "EEEE", { locale: ptBR })}</span>
                <span className="text-[9px] md:text-[10px] font-normal">{format(day, "dd/MM")}</span>
              </div>
            ))
          )}

          {/* Body */}
          {times.map((time, i) => (
            <React.Fragment key={i}>
              <div className="border-b border-r border-slate-100 h-12 flex items-center justify-center text-[10px] font-mono text-slate-400 bg-slate-50/50">
                {time}
              </div>
              {viewType === 'dia' ? (
                <TimeSlot 
                  date={currentDate}
                  time={time}
                  doctorId={selectedDoctor}
                  appointment={getAppointment(currentDate, time)} 
                  patientName={getAppointment(currentDate, time) ? getPatientName(getAppointment(currentDate, time)!.patientId) : ''}
                  block={getBlock(currentDate, time)}
                  isOutsideRegularHours={isOutsideRegularHours(currentDate, time)}
                  isLunchBreak={isLunchBreak(currentDate, time)}
                  isInactiveDay={isInactiveDay(currentDate)}
                  overbookStatus={getOverbookStatus(currentDate)}
                  onNewAppointment={onNewAppointment}
                  onBlockClick={handleBlockClick}
                />
              ) : (
                weekDays.map((day, j) => (
                  <TimeSlot 
                    key={j} 
                    date={day}
                    time={time}
                    doctorId={selectedDoctor}
                    appointment={getAppointment(day, time)} 
                    patientName={getAppointment(day, time) ? getPatientName(getAppointment(day, time)!.patientId) : ''}
                    block={getBlock(day, time)}
                    isOutsideRegularHours={isOutsideRegularHours(day, time)}
                    isLunchBreak={isLunchBreak(day, time)}
                    isInactiveDay={isInactiveDay(day)}
                    overbookStatus={getOverbookStatus(day)}
                    onNewAppointment={onNewAppointment}
                    onBlockClick={handleBlockClick}
                  />
                ))
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Confirmation Modal */}
      {blockToRemove && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Remover Bloqueio</h3>
            <p className="text-sm text-slate-600 mb-6">
              Tem certeza que deseja remover este bloqueio? O horário ficará disponível para agendamentos.
            </p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setBlockToRemove(null)}
                className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmRemoveBlock}
                className="px-4 py-2 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
              >
                Remover
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TimeSlot({ 
  date, 
  time, 
  doctorId, 
  appointment, 
  patientName, 
  block,
  isOutsideRegularHours,
  isLunchBreak,
  isInactiveDay,
  overbookStatus,
  onNewAppointment,
  onBlockClick
}: { 
  date: Date, 
  time: string, 
  doctorId: string, 
  appointment?: any, 
  patientName?: string, 
  block?: any,
  isOutsideRegularHours?: boolean,
  isLunchBreak?: boolean,
  isInactiveDay?: boolean,
  overbookStatus?: { allowed: boolean, max: number, current: number },
  onNewAppointment?: (date: string, time: string, doctorId: string) => void,
  onBlockClick?: (block: any) => void
}) {
  if (isInactiveDay) {
    return (
      <div className="border-b border-r border-slate-100 h-12 p-1 relative bg-slate-50 flex items-center justify-center">
        <span className="text-[9px] md:text-[10px] text-slate-300 font-medium text-center leading-tight">Não atende</span>
      </div>
    );
  }

  if (block) {
    return (
      <div 
        onClick={() => onBlockClick?.(block)}
        className="border-b border-r border-slate-100 h-12 p-1 relative bg-red-50/80 flex flex-col items-center justify-center text-red-500 cursor-pointer hover:bg-red-100/80 transition-colors"
        title="Clique para remover o bloqueio"
      >
        <Lock size={14} className="mb-0.5 opacity-60" />
        <span className="text-[9px] font-semibold uppercase tracking-wider truncate w-full text-center px-1">
          {block.reason || 'Bloqueado'}
        </span>
      </div>
    );
  }

  if (isLunchBreak) {
    return (
      <div className="border-b border-r border-slate-100 h-12 p-1 relative bg-slate-100/50 flex items-center justify-center">
        <span className="text-[9px] md:text-[10px] font-semibold uppercase tracking-wider text-slate-400 text-center leading-tight">
          <span className="md:hidden">Pausa</span>
          <span className="hidden md:inline">Almoço / Pausa</span>
        </span>
      </div>
    );
  }

  const isOverbookSlot = isOutsideRegularHours;
  const showAddButton = !appointment && (!isOverbookSlot || (overbookStatus && overbookStatus.max > 0));

  const handleAddClick = () => {
    if (isOverbookSlot && overbookStatus && !overbookStatus.allowed) {
      toast.error(`Limite de ${overbookStatus.max} encaixe(s) por dia atingido.`);
      return;
    }
    onNewAppointment?.(format(date, 'yyyy-MM-dd'), time, doctorId);
  };

  return (
    <div className={cn(
      "border-b border-r border-slate-100 h-12 p-0.5 relative group transition-colors",
      isOverbookSlot ? "bg-amber-50/30 hover:bg-amber-50/80" : "hover:bg-slate-50/50"
    )}>
      {appointment ? (
        <div className={cn(
          "h-full w-full rounded-md p-1.5 text-[10px] flex flex-col justify-between shadow-sm border-l-4",
          appointment.status === 'agendado' ? "bg-indigo-50 border-indigo-500 text-indigo-700" : "bg-emerald-50 border-emerald-500 text-emerald-700"
        )}>
          <p className="font-bold truncate uppercase">{patientName}</p>
          <p className="opacity-70 truncate">{appointment.procedure}</p>
        </div>
      ) : showAddButton ? (
        <button 
          onClick={handleAddClick}
          className={cn(
            "absolute inset-0 w-full h-full opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer",
            isOverbookSlot ? "text-amber-500" : "text-indigo-400"
          )}
          title={isOverbookSlot ? "Adicionar Encaixe" : "Novo Agendamento"}
        >
          <PlusCircle size={16} />
        </button>
      ) : (
        <div className="absolute inset-0 w-full h-full flex items-center justify-center">
          <span className="text-[9px] md:text-[10px] text-slate-300 font-medium text-center leading-tight">
            <span className="md:hidden">Indisp.</span>
            <span className="hidden md:inline">Não disponível</span>
          </span>
        </div>
      )}
    </div>
  );
}

function PlusCircle({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="16" />
      <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  );
}

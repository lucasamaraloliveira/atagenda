import React, { useState } from 'react';
import { X, Calendar, Clock, AlertCircle, Save, Plus, Check } from 'lucide-react';
import { Doctor, DaySchedule } from '@/lib/types';
import { cn } from '@/lib/utils';
import CustomSelect from './CustomSelect';
import { mockScheduleConfigs, mockScheduleBlocks } from '@/lib/mockData';
import { toast } from 'react-toastify';

interface DoctorScheduleModalProps {
  doctor: Doctor;
  onClose: () => void;
}

type Tab = 'escala' | 'bloqueio' | 'encaixe';

const defaultDaySchedule: DaySchedule = {
  active: false,
  startTime: '08:00',
  endTime: '18:00',
  lunchStart: '12:00',
  lunchEnd: '13:00'
};

export default function DoctorScheduleModal({ doctor, onClose }: DoctorScheduleModalProps) {
  const [activeTab, setActiveTab] = useState<Tab>('escala');

  // Load existing config if available
  const existingConfig = mockScheduleConfigs.find(c => c.doctorId === doctor.id);

  // Escala State
  const [schedule, setSchedule] = useState<Record<string, DaySchedule>>(
    existingConfig?.schedule || {
      '0': { ...defaultDaySchedule },
      '1': { ...defaultDaySchedule, active: true },
      '2': { ...defaultDaySchedule, active: true },
      '3': { ...defaultDaySchedule, active: true },
      '4': { ...defaultDaySchedule, active: true },
      '5': { ...defaultDaySchedule, active: true },
      '6': { ...defaultDaySchedule },
    }
  );
  const [selectedDay, setSelectedDay] = useState<string>('1');
  const [slotDuration, setSlotDuration] = useState(existingConfig?.slotDuration?.toString() || '15');

  const getPreset = () => {
    const activeDays = Object.keys(schedule).filter(day => schedule[day].active);
    if (activeDays.length === 5 && ['1', '2', '3', '4', '5'].every(d => activeDays.includes(d))) return 'weekdays';
    if (activeDays.length === 7) return 'everyday';
    if (activeDays.length === 0) return 'none';
    return 'custom';
  };

  const handlePresetChange = (preset: string) => {
    if (preset === 'custom') return;
    
    const newSchedule = { ...schedule };
    Object.keys(newSchedule).forEach(day => {
      if (preset === 'weekdays') {
        newSchedule[day] = { ...newSchedule[day], active: ['1', '2', '3', '4', '5'].includes(day) };
      } else if (preset === 'everyday') {
        newSchedule[day] = { ...newSchedule[day], active: true };
      } else if (preset === 'none') {
        newSchedule[day] = { ...newSchedule[day], active: false };
      }
    });
    setSchedule(newSchedule);
  };

  // Encaixe State
  const [maxOverbooks, setMaxOverbooks] = useState(existingConfig?.maxOverbooksPerDay?.toString() || '2');

  // Bloqueio State
  const [blockDate, setBlockDate] = useState('');
  const [blockStartTime, setBlockStartTime] = useState('');
  const [blockEndTime, setBlockEndTime] = useState('');
  const [blockReason, setBlockReason] = useState('');

  const daysOfWeek = [
    { id: '0', label: 'Dom' },
    { id: '1', label: 'Seg' },
    { id: '2', label: 'Ter' },
    { id: '3', label: 'Qua' },
    { id: '4', label: 'Qui' },
    { id: '5', label: 'Sex' },
    { id: '6', label: 'Sáb' },
  ];

  const handleSave = () => {
    // Here we would save the data based on the active tab
    if (activeTab === 'escala') {
      const configIndex = mockScheduleConfigs.findIndex(c => c.doctorId === doctor.id);
      if (configIndex >= 0) {
        mockScheduleConfigs[configIndex].schedule = schedule;
        mockScheduleConfigs[configIndex].slotDuration = parseInt(slotDuration);
      } else {
        mockScheduleConfigs.push({
          doctorId: doctor.id,
          maxOverbooksPerDay: parseInt(maxOverbooks),
          slotDuration: parseInt(slotDuration),
          schedule: schedule
        });
      }
      toast.success('Escala de horários salva com sucesso!');
    } else if (activeTab === 'encaixe') {
      const configIndex = mockScheduleConfigs.findIndex(c => c.doctorId === doctor.id);
      if (configIndex >= 0) {
        mockScheduleConfigs[configIndex].maxOverbooksPerDay = parseInt(maxOverbooks);
      }
      toast.success('Configuração de encaixes salva com sucesso!');
    } else if (activeTab === 'bloqueio') {
      if (blockDate && blockStartTime && blockEndTime) {
        mockScheduleBlocks.push({
          id: Math.random().toString(36).substr(2, 9),
          doctorId: doctor.id,
          date: blockDate,
          startTime: blockStartTime,
          endTime: blockEndTime,
          reason: blockReason || 'Bloqueado'
        });
        toast.success('Bloqueio de agenda criado com sucesso!');
      } else {
        toast.error('Preencha os campos obrigatórios do bloqueio.');
        return;
      }
    }
    console.log('Saving data for tab:', activeTab);
    onClose();
  };

  const updateSelectedDay = (field: keyof DaySchedule, value: any) => {
    setSchedule(prev => ({
      ...prev,
      [selectedDay]: {
        ...prev[selectedDay],
        [field]: value
      }
    }));
  };

  const currentDaySchedule = schedule[selectedDay];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50/50">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Configuração de Agenda</h2>
            <p className="text-sm text-slate-500 mt-1">Dr(a). {doctor.name} • CRM {doctor.crm}</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 px-6 pt-2 bg-slate-50/50">
          <button
            onClick={() => setActiveTab('escala')}
            className={cn(
              "px-4 py-3 text-sm font-semibold border-b-2 transition-colors",
              activeTab === 'escala' 
                ? "border-indigo-600 text-indigo-600" 
                : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
            )}
          >
            Criar Escala
          </button>
          <button
            onClick={() => setActiveTab('bloqueio')}
            className={cn(
              "px-4 py-3 text-sm font-semibold border-b-2 transition-colors",
              activeTab === 'bloqueio' 
                ? "border-indigo-600 text-indigo-600" 
                : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
            )}
          >
            Bloqueio de Agenda
          </button>
          <button
            onClick={() => setActiveTab('encaixe')}
            className={cn(
              "px-4 py-3 text-sm font-semibold border-b-2 transition-colors",
              activeTab === 'encaixe' 
                ? "border-indigo-600 text-indigo-600" 
                : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
            )}
          >
            Encaixes
          </button>
        </div>

        {/* Content */}
        <div className={cn(
          "p-6 overflow-y-auto flex-1",
          activeTab === 'encaixe' && "min-h-[350px]"
        )}>
          {activeTab === 'escala' && (
            <div className="space-y-6">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5">
                <h3 className="text-sm font-bold text-slate-800 mb-4">Configuração Rápida</h3>
                <CustomSelect
                  options={[
                    { id: 'weekdays', name: 'Dias da semana (Segunda a Sexta)' },
                    { id: 'everyday', name: 'Todos os dias (Domingo a Domingo)' },
                    { id: 'none', name: 'Nenhum (Limpar todos)' },
                    { id: 'custom', name: 'Personalizada' }
                  ]}
                  value={getPreset()}
                  onChange={handlePresetChange}
                  className="w-full sm:w-80"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-3">Selecione o Dia da Semana</label>
                <div className="flex flex-wrap gap-2">
                  {daysOfWeek.map(day => (
                    <button
                      key={day.id}
                      onClick={() => setSelectedDay(day.id)}
                      className={cn(
                        "w-12 h-12 rounded-xl text-sm font-bold flex items-center justify-center transition-all border-2",
                        selectedDay === day.id
                          ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                          : "border-transparent bg-slate-100 text-slate-500 hover:bg-slate-200",
                        schedule[day.id].active && selectedDay !== day.id && "bg-indigo-100/50 text-indigo-600"
                      )}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800">
                    Horários para {daysOfWeek.find(d => d.id === selectedDay)?.label}
                  </h3>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <div className={cn(
                      "w-5 h-5 rounded flex items-center justify-center border transition-colors",
                      currentDaySchedule.active ? "bg-indigo-600 border-indigo-600" : "bg-white border-slate-300"
                    )}>
                      {currentDaySchedule.active && <Check size={14} className="text-white" />}
                    </div>
                    <span className="text-sm font-medium text-slate-700">Atender neste dia</span>
                    <input 
                      type="checkbox" 
                      className="hidden"
                      checked={currentDaySchedule.active}
                      onChange={(e) => updateSelectedDay('active', e.target.checked)}
                    />
                  </label>
                </div>

                {currentDaySchedule.active ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Expediente</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Início</label>
                          <div className="relative">
                            <input 
                              type="time" 
                              value={currentDaySchedule.startTime}
                              onChange={(e) => updateSelectedDay('startTime', e.target.value)}
                              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Fim</label>
                          <div className="relative">
                            <input 
                              type="time" 
                              value={currentDaySchedule.endTime}
                              onChange={(e) => updateSelectedDay('endTime', e.target.value)}
                              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Almoço / Pausa</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Início</label>
                          <div className="relative">
                            <input 
                              type="time" 
                              value={currentDaySchedule.lunchStart}
                              onChange={(e) => updateSelectedDay('lunchStart', e.target.value)}
                              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Fim</label>
                          <div className="relative">
                            <input 
                              type="time" 
                              value={currentDaySchedule.lunchEnd}
                              onChange={(e) => updateSelectedDay('lunchEnd', e.target.value)}
                              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-8 text-center text-slate-500 text-sm">
                    O médico não atende neste dia da semana.
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-200">
                <div className="max-w-xs space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Duração Padrão da Consulta</label>
                  <CustomSelect 
                    options={[
                      { id: '10', name: '10 minutos' },
                      { id: '15', name: '15 minutos' },
                      { id: '20', name: '20 minutos' },
                      { id: '30', name: '30 minutos' },
                      { id: '60', name: '1 hora' },
                    ]}
                    value={slotDuration}
                    onChange={setSlotDuration}
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'bloqueio' && (
            <div className="space-y-6">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3 text-amber-800">
                <AlertCircle className="shrink-0 mt-0.5" size={18} />
                <p className="text-sm">
                  O bloqueio de agenda impede novos agendamentos no período selecionado. 
                  Agendamentos já existentes não serão cancelados automaticamente.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-1.5 md:col-span-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Data do Bloqueio</label>
                  <div className="relative">
                    <input 
                      type="date" 
                      value={blockDate}
                      onChange={(e) => setBlockDate(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Horário Inicial</label>
                  <div className="relative">
                    <input 
                      type="time" 
                      value={blockStartTime}
                      onChange={(e) => setBlockStartTime(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Horário Final</label>
                  <div className="relative">
                    <input 
                      type="time" 
                      value={blockEndTime}
                      onChange={(e) => setBlockEndTime(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  </div>
                </div>
                <div className="space-y-1.5 md:col-span-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Motivo do Bloqueio</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Férias, Congresso, Reunião..."
                    value={blockReason}
                    onChange={(e) => setBlockReason(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'encaixe' && (
            <div className="space-y-6">
              <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 flex gap-3 text-indigo-800">
                <Plus className="shrink-0 mt-0.5" size={18} />
                <p className="text-sm">
                  Defina o limite de encaixes permitidos por dia para este médico. 
                  Os encaixes podem ser agendados fora dos horários regulares da escala.
                </p>
              </div>

              <div className="max-w-xs space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Limite de Encaixes por Dia</label>
                <CustomSelect 
                  options={[
                    { id: '0', name: 'Não permitir encaixes' },
                    { id: '1', name: '1 encaixe' },
                    { id: '2', name: '2 encaixes' },
                    { id: '3', name: '3 encaixes' },
                    { id: '4', name: '4 encaixes' },
                    { id: '5', name: '5 encaixes' },
                    { id: '10', name: '10 encaixes' },
                  ]}
                  value={maxOverbooks}
                  onChange={setMaxOverbooks}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
          >
            Cancelar
          </button>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-md shadow-indigo-200"
          >
            <Save size={18} />
            Salvar Configurações
          </button>
        </div>

      </div>
    </div>
  );
}

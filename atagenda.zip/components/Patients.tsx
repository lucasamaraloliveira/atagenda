'use client';

import React, { useState } from 'react';
import { Search, Plus, Edit2, Trash2, MoreVertical, UserPlus } from 'lucide-react';
import { mockPatients } from '@/lib/mockData';
import { cn } from '@/lib/utils';

export default function Patients() {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPatients = mockPatients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.cpf.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por nome ou CPF..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-sm">
          <UserPlus size={18} />
          Novo Paciente
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Desktop Table View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-[11px] font-bold uppercase tracking-wider text-slate-500">Paciente</th>
                <th className="px-6 py-4 text-[11px] font-bold uppercase tracking-wider text-slate-500">CPF</th>
                <th className="px-6 py-4 text-[11px] font-bold uppercase tracking-wider text-slate-500">Nascimento</th>
                <th className="px-6 py-4 text-[11px] font-bold uppercase tracking-wider text-slate-500">Contato</th>
                <th className="px-6 py-4 text-[11px] font-bold uppercase tracking-wider text-slate-500 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPatients.map((patient) => (
                <tr key={patient.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                        {patient.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900">{patient.name}</p>
                        <p className="text-xs text-slate-500">{patient.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600 font-mono">{patient.cpf}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {new Date(patient.birthDate).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{patient.phone}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Card View */}
        <div className="md:hidden divide-y divide-slate-100">
          {filteredPatients.map((patient) => (
            <div key={patient.id} className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    {patient.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 leading-tight">{patient.name}</p>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">{patient.cpf}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button className="p-2 text-indigo-600 rounded-lg">
                    <Edit2 size={16} />
                  </button>
                  <button className="p-2 text-red-600 rounded-lg">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2">
                <div className="bg-slate-50 p-2 rounded-lg">
                  <p className="text-[9px] text-slate-400 uppercase font-bold">Nascimento</p>
                  <p className="text-xs text-slate-700 font-medium">{new Date(patient.birthDate).toLocaleDateString('pt-BR')}</p>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg">
                  <p className="text-[9px] text-slate-400 uppercase font-bold">Telefone</p>
                  <p className="text-xs text-slate-700 font-medium">{patient.phone}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        {filteredPatients.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-slate-500">Nenhum paciente encontrado.</p>
          </div>
        )}
      </div>
    </div>
  );
}

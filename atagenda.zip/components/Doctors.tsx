'use client';

import React, { useState } from 'react';
import { Search, Plus, Edit2, Trash2, UserRound, Stethoscope } from 'lucide-react';
import { mockDoctors } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { Doctor } from '@/lib/types';
import DoctorScheduleModal from './DoctorScheduleModal';

export default function Doctors() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  
  const filteredDoctors = mockDoctors.filter(d => 
    d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.crm.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por nome ou CRM..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-sm">
          <Stethoscope size={18} />
          Novo Médico
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDoctors.map((doctor) => (
          <div key={doctor.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group relative">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                <UserRound size={24} />
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg">
                  <Edit2 size={16} />
                </button>
                <button className="p-2 hover:bg-red-50 text-red-600 rounded-lg">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            
            <h3 className="font-bold text-slate-900 mb-1">{doctor.name}</h3>
            <p className="text-sm text-indigo-600 font-medium mb-3">{doctor.specialty}</p>
            
            <div className="space-y-2 pt-4 border-t border-slate-100">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">CRM</span>
                <span className="font-mono font-semibold text-slate-700">{doctor.crm}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Tipo</span>
                <span className="capitalize font-semibold text-slate-700">{doctor.type}</span>
              </div>
            </div>

            <button 
              onClick={() => setSelectedDoctor(doctor)}
              className="w-full mt-6 py-2 text-xs font-bold text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Ver Escala de Horários
            </button>
          </div>
        ))}
      </div>
      
      {filteredDoctors.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <p className="text-slate-500">Nenhum médico encontrado.</p>
        </div>
      )}

      {selectedDoctor && (
        <DoctorScheduleModal 
          doctor={selectedDoctor} 
          onClose={() => setSelectedDoctor(null)} 
        />
      )}
    </div>
  );
}

'use client';

import React from 'react';
import { 
  Calendar, 
  Users, 
  UserRound, 
  History, 
  PlusCircle,
  Menu,
  X,
  LogOut
} from 'lucide-react';
import { View } from '@/lib/types';
import { cn } from '@/lib/utils';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export default function Sidebar({ currentView, setView, isOpen, setIsOpen }: SidebarProps) {
  const menuItems = [
    { id: 'novo-agendamento', label: 'Novo Agendamento', icon: PlusCircle, primary: true },
    { id: 'agenda', label: 'Agenda', icon: Calendar },
    { id: 'pacientes', label: 'Pacientes', icon: Users },
    { id: 'medicos', label: 'Médicos', icon: UserRound },
    { id: 'historico', label: 'Histórico', icon: History },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 shadow-2xl lg:shadow-none",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full flex flex-col">
          <div className="p-4 md:p-6 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-bold shrink-0">
                AT
              </div>
              <span className="font-bold text-lg md:text-xl tracking-tight">ATAgenda</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="lg:hidden p-2 hover:bg-slate-100 rounded-lg text-slate-500">
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setView(item.id as View);
                  if (window.innerWidth < 1024) setIsOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  currentView === item.id 
                    ? "bg-indigo-50 text-indigo-700" 
                    : item.primary 
                      ? "bg-indigo-600 text-white hover:bg-indigo-700 mb-4"
                      : "text-slate-600 hover:bg-slate-50"
                )}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-100">
            <div className="flex items-center gap-3 px-3 py-2 text-sm text-slate-500">
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">
                L
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="font-medium text-slate-900 truncate">Lucas Silva</p>
                <p className="text-xs truncate">Administrador</p>
              </div>
              <button className="p-1 hover:bg-slate-100 rounded">
                <LogOut size={16} />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}

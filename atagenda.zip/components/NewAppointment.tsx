'use client';

import React, { useState } from 'react';
import { Search, Plus, Save, X, User, Phone, Stethoscope, ClipboardList, Clock, ChevronDown } from 'lucide-react';
import { mockPatients, mockDoctors, mockAppointments } from '@/lib/mockData';
import CustomSelect from './CustomSelect';
import { toast } from 'react-toastify';

interface NewAppointmentProps {
  initialData?: { date?: string, time?: string, doctorId?: string } | null;
  onCancel?: () => void;
}

export default function NewAppointment({ initialData, onCancel }: NewAppointmentProps) {
  const [formData, setFormData] = useState({
    patientName: '',
    phone: '',
    referringDoctor: '',
    insurance: '',
    executingDoctor: initialData?.doctorId || '',
    modality: '',
    procedure: '',
    date: initialData?.date || '',
    time: initialData?.time || ''
  });

  const [showPatientDropdown, setShowPatientDropdown] = useState(false);

  React.useEffect(() => {
    if (initialData) {
      setFormData(prev => ({
        ...prev,
        date: initialData.date || prev.date,
        time: initialData.time || prev.time,
        executingDoctor: initialData.doctorId || prev.executingDoctor
      }));
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Find or create patient
    let patientId = mockPatients.find(p => p.name === formData.patientName)?.id;
    if (!patientId) {
      patientId = Math.random().toString(36).substr(2, 9);
      mockPatients.push({
        id: patientId,
        name: formData.patientName,
        cpf: '',
        birthDate: '',
        gender: '',
        phone: formData.phone,
        email: ''
      });
    }

    // Create appointment
    const newAppointment = {
      id: Math.random().toString(36).substr(2, 9),
      patientId,
      doctorId: formData.executingDoctor,
      date: formData.date,
      time: formData.time,
      procedure: formData.procedure || 'Consulta',
      insurance: formData.insurance || 'Particular',
      status: 'agendado' as const
    };

    mockAppointments.push(newAppointment);
    
    toast.success('Agendamento criado com sucesso!');

    if (onCancel) {
      onCancel(); // Go back to agenda
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    return `${day}/${month}/${year}`;
  };

  const formatPhone = (value: string) => {
    if (!value) return '';
    const numbers = value.replace(/\D/g, '');
    if (numbers.length === 0) return '';
    if (numbers.length <= 2) return `(${numbers}`;
    if (numbers.length <= 6) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    if (numbers.length <= 10) return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 6)}-${numbers.slice(6)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handlePatientNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    // Se estiver digitando apenas números e barras, aplica máscara de data (DD/MM/AAAA)
    if (/^[\d/]+$/.test(value)) {
      const numbers = value.replace(/\D/g, '');
      if (numbers.length <= 2) value = numbers;
      else if (numbers.length <= 4) value = `${numbers.slice(0, 2)}/${numbers.slice(2)}`;
      else value = `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}/${numbers.slice(4, 8)}`;
    }
    setFormData({...formData, patientName: value});
    setShowPatientDropdown(true);
  };

  const filteredPatients = mockPatients.filter(p => {
    if (!formData.patientName) return false;
    const query = formData.patientName.toLowerCase();
    const nameMatch = p.name.toLowerCase().includes(query);
    const dobMatch = p.birthDate ? formatDate(p.birthDate).includes(query) : false;
    return nameMatch || dobMatch;
  });

  const handlePatientSelect = (patient: typeof mockPatients[0]) => {
    setFormData({
      ...formData,
      patientName: patient.name,
      phone: patient.phone || ''
    });
    setShowPatientDropdown(false);
  };

  const doctorOptions = mockDoctors.map(d => ({ id: d.id, name: d.name }));
  const insuranceOptions = [
    { id: 'bradesco', name: 'Bradesco' },
    { id: 'unimed', name: 'Unimed' },
    { id: 'sulamerica', name: 'SulAmérica' },
    { id: 'particular', name: 'Particular' },
  ];
  const modalityOptions = [
    { id: 'us', name: 'US (Ultrassom)' },
    { id: 'rx', name: 'RX (Raio-X)' },
    { id: 'ct', name: 'CT (Tomografia)' },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50">
          <h2 className="text-lg font-bold text-slate-900">Formulário de Agendamento</h2>
          <p className="text-sm text-slate-500">Preencha os dados abaixo para realizar um novo agendamento.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {/* Patient Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600 mb-2">
              <User size={18} />
              <h3 className="text-sm font-bold uppercase tracking-wider">Dados do Paciente</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5 relative">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Paciente</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Nome ou data de nascimento (DD/MM/AAAA)"
                    className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                    value={formData.patientName}
                    onChange={handlePatientNameChange}
                    onFocus={() => setShowPatientDropdown(true)}
                    onBlur={() => setTimeout(() => setShowPatientDropdown(false), 200)}
                  />
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                </div>
                
                {showPatientDropdown && formData.patientName && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg max-h-60 overflow-y-auto">
                    {filteredPatients.length > 0 ? (
                      filteredPatients.map(patient => (
                        <div 
                          key={patient.id}
                          className="px-4 py-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 last:border-0 transition-colors"
                          onClick={() => handlePatientSelect(patient)}
                        >
                          <div className="font-medium text-slate-900 text-sm">{patient.name}</div>
                          <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                            <span>DN: {formatDate(patient.birthDate)}</span>
                            {patient.cpf && <span>• CPF: {patient.cpf}</span>}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="px-4 py-3 text-sm text-slate-500 italic">
                        Nenhum paciente encontrado. Um novo cadastro será criado.
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Telefone para Contato</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="(00) 00000-0000"
                    maxLength={15}
                    className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: formatPhone(e.target.value)})}
                  />
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                </div>
              </div>
            </div>
          </section>

          {/* Medical Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600 mb-2">
              <Stethoscope size={18} />
              <h3 className="text-sm font-bold uppercase tracking-wider">Dados Médicos</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Médico Solicitante</label>
                <input 
                  type="text" 
                  placeholder="Nome do médico ou CRM"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={formData.referringDoctor}
                  onChange={(e) => setFormData({...formData, referringDoctor: e.target.value})}
                />
              </div>
              <CustomSelect 
                label="Convênio"
                placeholder="Selecione o convênio"
                options={insuranceOptions}
                value={formData.insurance}
                onChange={(val) => setFormData({...formData, insurance: val})}
              />
            </div>
          </section>

          {/* Procedure Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600 mb-2">
              <ClipboardList size={18} />
              <h3 className="text-sm font-bold uppercase tracking-wider">Procedimento</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <CustomSelect 
                label="Médico Executante"
                placeholder="Selecione o médico"
                options={doctorOptions}
                value={formData.executingDoctor}
                onChange={(val) => setFormData({...formData, executingDoctor: val})}
              />
              <CustomSelect 
                label="Modalidade"
                placeholder="Selecione"
                options={modalityOptions}
                value={formData.modality}
                onChange={(val) => setFormData({...formData, modality: val})}
              />
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Procedimento</label>
                <input 
                  type="text" 
                  placeholder="Ex: US Abdome Total"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={formData.procedure}
                  onChange={(e) => setFormData({...formData, procedure: e.target.value})}
                />
              </div>
            </div>
          </section>

          {/* Schedule Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600 mb-2">
              <Clock size={18} />
              <h3 className="text-sm font-bold uppercase tracking-wider">Data e Horário</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Data</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Horário</label>
                <input 
                  type="time" 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                  value={formData.time}
                  onChange={(e) => setFormData({...formData, time: e.target.value})}
                />
              </div>
            </div>
          </section>

          <div className="pt-6 flex items-center justify-end gap-3">
            <button 
              type="button" 
              onClick={onCancel}
              className="px-6 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button type="submit" className="flex items-center gap-2 px-8 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-md shadow-indigo-200">
              <Save size={18} />
              Salvar Agendamento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
